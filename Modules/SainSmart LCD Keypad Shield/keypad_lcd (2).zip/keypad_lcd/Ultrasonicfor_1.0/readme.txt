The are some examples in  LCD4884\examples .
	And each example have a <readme.txt>file  to illustrate how to use the example.
	enjoy it.