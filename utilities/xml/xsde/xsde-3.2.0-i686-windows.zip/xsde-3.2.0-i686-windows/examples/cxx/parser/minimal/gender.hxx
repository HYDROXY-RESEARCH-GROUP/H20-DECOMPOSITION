// file      : examples/cxx/parser/minimal/gender.hxx
// author    : Boris Kolpackov <boris@codesynthesis.com>
// copyright : not copyrighted - public domain

#ifndef GENDER_HXX
#define GENDER_HXX

enum gender
{
  male,
  female
};

#endif // GENDER_HXX
