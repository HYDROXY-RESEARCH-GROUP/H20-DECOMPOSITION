This directory contains a number of examples that show how to customize 
the C++/Hybrid object model. The following list gives an overview of 
each example:

wildcard
  Shows how to parse, store in the object model, and serialize XML data
  matched by XML Schema wildcards (any and anyAttribute).
