// file      : examples/cxx/hybrid/custom/wildcard/envelope.cxx
// author    : Boris Kolpackov <boris@codesynthesis.com>
// copyright : not copyrighted - public domain

// Include email.hxx (which includes envelope.hxx) instead of envelope.hxx.
//
#include "email.hxx"

namespace email
{
}
